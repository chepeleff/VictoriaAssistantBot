package userInteractions;

public enum UserRole {
    USER,
    ADMIN
}
