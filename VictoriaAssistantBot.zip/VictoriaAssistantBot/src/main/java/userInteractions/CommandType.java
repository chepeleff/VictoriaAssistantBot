package userInteractions;

public enum CommandType {
    EMPTY,
    ADD_QUESTION,
    SHOW_QUESTIONS,
    CLEAN_QUESTIONS,
    SET_ROLE
}
